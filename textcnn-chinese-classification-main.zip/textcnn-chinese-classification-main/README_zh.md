🇬🇧 [EN](./README.md) | 🇨🇳 [中文](./README_zh.md)

# TextCNN 中文文本分类

基于TextCNN的中文文本分类项目，使用PyTorch实现。

> **说明**: 本项目基于 [649453932](https://github.com/649453932) 的优秀工作 [Chinese-Text-Classification-Pytorch](https://github.com/649453932/Chinese-Text-Classification-Pytorch)。原仓库提供了多种文本分类模型的实现，包括TextCNN、TextRNN、FastText、TextRCNN、BiLSTM_Attention、DPCNN和Transformer。

## 项目结构

```
.
├── models/                    # 模型定义
│   ├── TextCNN.py            # TextCNN模型实现
│   ├── TextRNN.py            # TextRNN模型实现
│   ├── FastText.py           # FastText模型实现
│   └── Transformer.py        # Transformer模型实现
├── utils.py                  # 通用工具函数
├── utils_fasttext.py         # FastText风格的工具函数
├── train_eval.py             # 训练和评估函数
├── main.py                   # 主程序入口
├── requirements.txt          # Python依赖包
├── README.md                 # 英文文档
├── README_zh.md              # 中文文档
└── THUCNews/                 # 数据集目录
    ├── data/
    │   ├── train.txt         # 训练集（18万条数据）
    │   ├── dev.txt           # 验证集（1万条数据）
    │   ├── test.txt          # 测试集（1万条数据）
    │   ├── class.txt         # 类别标签
    │   └── vocab.pkl         # 词表文件
    ├── saved_dict/           # 模型检查点
    └── log/                  # 训练日志
```

## 数据集信息

### THUCNews数据集
本项目使用THUCNews数据集，具体数据分布如下：

- 训练集：180,000条数据
- 验证集：10,000条数据
- 测试集：10,000条数据

### 预训练词向量
本项目支持使用预训练的中文词向量，推荐使用以下来源的词向量：

1. 搜狗新闻词向量（默认）
   - 来源：搜狗实验室
   - 语料大小：3.7G
   - 词表大小：1.2M
   - 下载地址：[搜狗新闻词向量](http://www.sogou.com/labs/)

2. 其他可选词向量（来自Chinese-Word-Vectors项目）：
   - 百度百科词向量（4.1G，5.4M词表）
   - 中文维基词向量（1.3G，2.1M词表）
   - 人民日报词向量（3.9G，1.6M词表）
   - 金融新闻词向量（6.2G，2.7M词表）
   - 知乎问答词向量（2.1G，1.1M词表）
   - 微博词向量（0.73G，850K词表）
   - 文学作品词向量（0.93G，702K词表）

更多词向量资源请参考：[Chinese-Word-Vectors](https://github.com/Embedding/Chinese-Word-Vectors)

## 模型特点

TextCNN模型具有以下特点：

1. 使用卷积神经网络进行文本分类
2. 采用n-gram特征提取：
   - 使用bigram（二元组）和trigram（三元组）特征
   - n-gram特征空间大小：250499（哈希桶大小）
   - 通过哈希函数将连续的词组合映射到固定大小的特征空间

## 配置参数

主要配置参数包括：

```python
self.num_epochs = 20            # 训练轮数
self.batch_size = 128          # 批次大小
self.pad_size = 32             # 每句话处理成的长度(短填长切)
self.learning_rate = 1e-3      # 学习率
self.embed = 300               # 字向量维度
self.filter_sizes = (2, 3, 4)  # 卷积核尺寸
self.num_filters = 256         # 卷积核数量
```

## 运行方式

```bash
# 使用随机初始化的词向量
python main.py --model TextCNN --embedding random

# 使用预训练词向量
python main.py --model TextCNN --embedding pre_trained
```

## 训练过程

每个epoch的处理量：
- 训练集：180,000条 × 20轮 = 3,600,000条数据
- 验证集：10,000条 × 20轮 = 200,000条数据
- 测试集：10,000条（仅在训练结束后评估一次）

## 环境要求

- Python 3.x
- PyTorch
- NumPy
- tqdm

## 注意事项

1. 确保数据集已正确放置在THUCNews/data/目录下
2. 首次运行时会自动构建词表
3. 模型会自动使用GPU（如果可用）或CPU进行训练
4. 使用预训练词向量时，请确保词向量文件已正确放置在THUCNews/data/目录下

---

[English Version README.md](README.md) 