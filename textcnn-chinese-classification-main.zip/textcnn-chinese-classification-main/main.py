# coding: UTF-8
import time
import torch
import numpy as np
from train_eval import train, init_network  # 训练与模型参数初始化函数
from importlib import import_module
import argparse

# ----------- 参数配置 -----------
parser = argparse.ArgumentParser(description='Chinese Text Classification')
parser.add_argument('--model', type=str, required=True,
                    help='choose a model: TextCNN, TextRNN, FastText, TextRCNN, TextRNN_Att, DPCNN, Transformer')
parser.add_argument('--embedding', default='pre_trained', type=str, help='random or pre_trained')
parser.add_argument('--word', default=False, type=bool, help='True for word, False for char')
args = parser.parse_args()

if __name__ == '__main__':
    dataset = 'THUCNews'  # 数据集名称

    # 指定词向量文件（可以选用搜狗新闻/腾讯/随机初始化）
    embedding = 'embedding_SougouNews.npz'
    if args.embedding == 'random':
        embedding = 'random'
    model_name = args.model  # 选择的模型名称

    # ----------- 动态导入工具函数和模型配置 -----------
    if model_name == 'TextCNN':
        # TextCNN特殊，使用带ngram的utils
        from utils_fasttext import build_dataset, build_iterator, get_time_dif

        embedding = 'random'  # TextCNN一般不用预训练词向量
    else:
        from utils import build_dataset, build_iterator, get_time_dif

    x = import_module('models.' + model_name)  # 动态导入模型模块
    config = x.Config(dataset, embedding)  # 创建模型配置对象
    np.random.seed(1)  # 固定numpy随机种子，保证实验可复现
    torch.manual_seed(1)  # 固定torch随机种子
    torch.cuda.manual_seed(1)
    torch.backends.cudnn.deterministic = True  # 固定cudnn，确保每次结果一致

    # ----------- 数据加载与预处理 -----------
    start_time = time.time()
    print('Loading data...')
    vocab, train_data, dev_data, test_data = build_dataset(config, args.word)  # 构建词表和数据集
    train_iter = build_iterator(train_data, config)  # 构建训练数据迭代器
    dev_iter = build_iterator(dev_data, config)  # 验证集迭代器
    test_iter = build_iterator(test_data, config)  # 测试集迭代器
    time_dif = get_time_dif(start_time)
    print('Time usage: ', time_dif)

    # ----------- 训练准备 -----------
    config.n_vocab = len(vocab)  # 词表大小写入config
    model = x.Model(config).to(config.device)  # 初始化模型，转到指定设备
    if model_name != 'Transformer':
        init_network(model)  # 除了Transformer都要初始化权重
    print(model.parameters)

    # ----------- 正式训练 -----------
    train(config, model, train_iter, dev_iter, test_iter)
