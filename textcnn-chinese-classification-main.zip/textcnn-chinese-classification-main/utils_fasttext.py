# coding: UTF-8
import os
import torch
import numpy as np
import pickle as pkl
from tqdm import tqdm
import time
from datetime import timedelta


MAX_VOCAB_SIZE = 10000
UNK, PAD = '<UNK>', '<PAD>'


def build_vocab(file_path, tokenizer, max_size, min_freq):
    vocab_dic = {}
    with open(file_path, 'r', encoding='UTF-8') as f:
        for line in tqdm(f):
            lin = line.strip()
            if not lin:
                continue
            content = lin.split('\t')[0]
            for word in tokenizer(content):
                vocab_dic[word] = vocab_dic.get(word, 0) + 1
        vocab_list = sorted(
            [_ for _ in vocab_dic.items() if _[1] >= min_freq],
            key=lambda x: x[1],
            reverse=True
        )[:max_size]
        vocab_dic = {word_count[0]: idx for idx, word_count in enumerate(vocab_list)}
        vocab_dic.update({UNK: len(vocab_dic), PAD: len(vocab_dic) + 1})
    return vocab_dic



def build_dataset(config, use_word):
    # 选择分词方式，按单词还是按字符
    if use_word:
        tokenizer = lambda x: x.split(' ')  # 单词级别分词
    else:
        tokenizer = lambda x: [y for y in x]  # 字符级别分词

    # 加载已保存的词表，如果没有则重新构建并保存
    if os.path.exists(config.vocab_path):
        vocab = pkl.load(open(config.vocab_path, 'rb'))
    else:
        vocab = build_vocab(config.train_path, tokenizer=tokenizer, max_size=MAX_VOCAB_SIZE, min_freq=1)
        pkl.dump(vocab, open(config.vocab_path, 'wb'))
    print(f"Vocab size: {len(vocab)}")  # 打印词表大小

    # 定义二元组hash，模拟fastText的bigram特征
    def biGramHash(sequence, t, buckets):
        t1 = sequence[t - 1] if t - 1 >= 0 else 0  # 取前一个token的id，第一位没有就取0
        return (t1 * 14918087) % buckets           # 通过hash函数映射到buckets范围

    # 定义三元组hash，模拟fastText的trigram特征
    def triGramHash(sequence, t, buckets):
        t1 = sequence[t - 1] if t - 1 >= 0 else 0  # 前一位
        t2 = sequence[t - 2] if t - 2 >= 0 else 0  # 前两位
        return (t2 * 14918087 * 18408749 + t1 * 14918087) % buckets  # hash到buckets范围

    # 加载数据集，每个样本处理成“id序列+ngram hash特征”
    def load_dataset(path, pad_size=32):
        contents = []
        with open(path, 'r', encoding='UTF-8') as f:
            for line in tqdm(f):
                line = line.strip()
                if not line:
                    continue
                content, label = line.split('\t')  # 拆分文本和标签
                words_line = []
                token = tokenizer(content)        # 分词
                seq_len = len(token)              # 原始序列长度
                # 长度不足pad_size则补PAD，超长则截断
                if pad_size:
                    if len(token) < pad_size:
                        token.extend([PAD] * (pad_size - len(token)))
                    else:
                        token = token[:pad_size]
                        seq_len = pad_size
                # 词转id，UNK用特殊id
                for word in token:
                    words_line.append(vocab.get(word, vocab.get(UNK)))

                # 生成fastText风格的 bigram 和 trigram hash特征
                buckets = config.n_gram_vocab  # hash桶数量（ngram特征空间大小）
                bigram = []
                trigram = []
                for i in range(pad_size):
                    bigram.append(biGramHash(words_line, i, buckets))    # bigram特征
                    trigram.append(triGramHash(words_line, i, buckets))  # trigram特征

                # 保存格式：(词id序列, 标签, 序列长度, bigram特征, trigram特征)
                contents.append((words_line, int(label), seq_len, bigram, trigram))
        return contents

    # 分别处理train/dev/test集
    train = load_dataset(config.train_path, config.pad_size)
    dev = load_dataset(config.dev_path, config.pad_size)
    test = load_dataset(config.test_path, config.pad_size)
    return vocab, train, dev, test  # 返回词表和处理好的数据集


class DatasetIterater(object):
    def __init__(self, batches, batch_size, device):
        self.batch_size = batch_size          # 每个batch的数据量
        self.batches = batches                # 数据集列表（每个元素包含id序列、标签、长度、bigram、trigram）
        self.n_batches = len(batches) // batch_size  # 能整分出多少完整batch
        self.residue = False                  # 是否有“残留batch”（最后一批不满batch_size）
        if len(batches) % self.n_batches != 0:
            self.residue = True
        self.index = 0                        # 当前batch的索引
        self.device = device                  # 设备（cpu/gpu）

    def _to_tensor(self, datas):
        # 把一个batch的所有特征转为Tensor，并放到指定设备上
        x = torch.LongTensor([_[0] for _ in datas]).to(self.device)         # 输入序列
        y = torch.LongTensor([_[1] for _ in datas]).to(self.device)         # 标签
        bigram = torch.LongTensor([_[3] for _ in datas]).to(self.device)    # bigram hash特征
        trigram = torch.LongTensor([_[4] for _ in datas]).to(self.device)   # trigram hash特征
        seq_len = torch.LongTensor([_[2] for _ in datas]).to(self.device)   # 原始长度
        # 返回((输入、长度、bigram、trigram), 标签)
        return (x, seq_len, bigram, trigram), y

    def __next__(self):
        # 实现迭代器协议，支持for ... in ... 方式遍历batch
        if self.residue and self.index == self.n_batches:
            # 处理最后不足batch_size的“残留batch”
            batches = self.batches[self.index * self.batch_size : len(self.batches)]
            self.index += 1
            batches = self._to_tensor(batches)
            return batches
        elif self.index >= self.n_batches:
            # 所有batch取完，重置索引，抛出StopIteration
            self.index = 0
            raise StopIteration
        else:
            # 正常取一个完整batch
            batches = self.batches[self.index * self.batch_size : (self.index + 1) * self.batch_size]
            self.index += 1
            batches = self._to_tensor(batches)
            return batches

    def __iter__(self):
        # 迭代器本体
        return self

    def __len__(self):
        # 总batch数（包含残留batch）
        if self.residue:
            return self.n_batches + 1
        else:
            return self.n_batches



def build_iterator(dataset, config):
    iter = DatasetIterater(dataset, config.batch_size, config.device)
    return iter


def get_time_dif(start_time):
    """获取已使用时间"""
    end_time = time.time()
    time_dif = end_time - start_time
    return timedelta(seconds=int(round(time_dif)))

if __name__ == "__main__":
    '''提取预训练词向量'''
    vocab_dir = "THUCNews/data/vocab.pkl"
    pretrain_dir = "./THUCNews/data/sgns.sogou.char"
    emb_dim = 300
    filename_trimmed_dir = "./THUCNews/data/vocab.embedding.sougou"
    word_to_id = pkl.load(open(vocab_dir, 'rb'))
    embeddings = np.random.rand(len(word_to_id), emb_dim)
    f = open(pretrain_dir, "r", encoding='UTF-8')
    for i, line in enumerate(f.readlines()):
        # if i == 0:  # 若第一行是标题，则跳过
        #     continue
        line = line.strip().split(" ")
        if line[0] in word_to_id:
            idx = word_to_id[line[0]]
            emb = [float(x) for x in line[1:301]]
            embeddings[idx] = np.asarray(emb, dtype='float32')
    f.close()
    np.savez_compressed(filename_trimmed_dir, embeddings=embeddings)
