import os
import torch
import numpy as np
import pickle as pkl
from tqdm import tqdm
import time
from datetime import timedelta

MAX_VOCAB_SIZE = 10000
UNK, PAD = '<UNK>', '<PAD>'

def build_vocab(file_path, tokenizer, max_size, min_freq):
    vocab_dic = {}  # 用来统计每个词出现的次数（词频）
    with open(file_path, 'r', encoding='utf-8') as f:
        for line in tqdm(f):  # tqdm显示进度条
            line = line.strip()  # 去除行首尾空白符
            if not line:  # 跳过空行
                continue
            content = line.split('\t')[0]  # 获取每行第一个字段（文本内容）
            for word in tokenizer(content):  # 用分词器对内容分词
                vocab_dic[word] = vocab_dic.get(word, 0) + 1  # 统计词频

        # 过滤掉低频词，只保留词频大于等于min_freq的词，并按词频排序，最多保留max_size个词
        vocab_list = sorted(
            [_ for _ in vocab_dic.items() if _[1] >= min_freq],
            key=lambda x: x[1],
            reverse=True
        )[:max_size]
        # 将词表中的词映射为索引（从0开始编号）
        vocab_dic = {word_count[0]: idx for idx, word_count in enumerate(vocab_list)}
        # 添加特殊符号：UNK（未知词）、PAD（补全用），并分配索引
        vocab_dic.update({UNK: len(vocab_dic), PAD: len(vocab_dic) + 1})
    return vocab_dic  # 返回词到索引的映射字典


def build_dataset(config, use_word):
    # 选择分词方式：按单词分还是按字符分
    if use_word:
        tokenizer = lambda x: x.split(' ')  # 按空格切分，得到单词
    else:
        tokenizer = lambda x: [y for y in x]  # 按字符切分

    # 检查是否已有词表文件
    if os.path.exists(config.vocab_path):
        vocab = pkl.load(open(config.vocab_path, 'rb'))  # 直接加载已保存的词表
    else:
        # 没有就重新构建词表，并保存到文件
        vocab = build_vocab(config.train_path, tokenizer=tokenizer, max_size=MAX_VOCAB_SIZE, min_freq=1)
        pkl.dump(vocab, open(config.vocab_path, 'wb'))
    print(f"Vocab size: {len(vocab)}")  # 打印词表大小

    # 内部函数，负责加载指定文件（train/dev/test），并把内容处理成可用于训练的数据格式
    def load_dataset(path, pad_size=32):
        contents = []
        with open(path, 'r', encoding='utf-8') as f:
            for line in tqdm(f):  # tqdm显示处理进度
                line = line.strip()  # 去掉首尾空白
                if not line:  # 跳过空行
                    continue
                content, label = line.split('\t')  # 分割出文本和标签
                words_line = []
                token = tokenizer(content)  # 对文本进行分词
                seq_len = len(token)  # 记录实际序列长度
                # 长度不足pad_size则补PAD，超长则截断
                if pad_size:
                    if len(token) < pad_size:
                        token.extend([PAD] * (pad_size - len(token)))
                    else:
                        token = token[:pad_size]
                        seq_len = pad_size
                # 把分词后的每个词/字符转为词表中的编号（不在词表的用UNK编号）
                for word in token:
                    words_line.append(vocab.get(word, vocab.get(UNK)))
                # 保存：(编号序列，标签，实际长度)
                contents.append((words_line, int(label), seq_len))

        return contents  # 返回所有样本

    # 分别加载训练集、验证集、测试集
    train = load_dataset(config.train_path, config.pad_size)
    dev = load_dataset(config.dev_path, config.pad_size)
    test = load_dataset(config.test_path, config.pad_size)
    return vocab, train, dev, test  # 返回词表和3个数据集


class DatasetIterator(object):
    def __init__(self, batches, batch_size, device):
        self.batch_size = batch_size  # 每个batch的样本数量
        self.batches = batches        # 全部数据（已处理成数字id等格式的样本列表）
        self.n_batches = len(batches) // self.batch_size  # 整除后能分多少个完整batch
        self.residue = False          # 是否有“残留batch”（最后一批不满batch_size）
        if len(batches) % self.batch_size != 0:
            self.residue = True
        self.index = 0                # 当前batch的索引
        self.device = device          # 数据要放到哪个设备（cpu/gpu）

    def _to_tensor(self, datum):
        # 把一个batch的数据转成tensor
        x = torch.LongTensor([_[0] for _ in datum]).to(self.device)      # 取出样本的输入部分（序列id）
        y = torch.LongTensor([_[1] for _ in datum]).to(self.device)      # 取出标签
        seq_len = torch.LongTensor([_[2] for _ in datum]).to(self.device) # 取出每个样本的实际长度
        return (x, seq_len), y    # 返回((序列, 长度), 标签)

    def __next__(self):
        # 获取下一个batch
        if self.residue and self.index == self.n_batches:
            # 如果有 残余batch且正好轮到最后一个batch
            batches = self.batches[self.index * self.batch_size : len(self.batches)]
            self.index += 1
            batches = self._to_tensor(batches)
            return batches

        elif self.index >= self.n_batches:
            # 所有batch都取完，重置index并抛出StopIteration
            self.index = 0
            raise StopIteration
        else:
            # 正常取一个完整的batch
            batches = self.batches[self.index * self.batch_size : (self.index + 1) * self.batch_size]
            self.index += 1
            batches = self._to_tensor(batches)
            return batches

    def __iter__(self):
        # 让这个对象可被for...in迭代
        return self

    def __len__(self):
        # 返回总batch数，包括残余batch
        if self.residue:
            return self.n_batches + 1
        else:
            return self.n_batches



def build_iterator(dataset, config):
    # 构建数据迭代器，按batch读取数据
    iter = DatasetIterator(dataset, config.batch_size, config.device)
    return iter

def get_time_dif(start_time):
    # 计算程序运行的时间差（秒），返回timedelta对象
    end_time = time.time()
    time_dif = end_time - start_time
    return timedelta(seconds=int(round(time_dif)))

if __name__ == '__main__':
    train_dir = "./THUCNews/data/train.txt"               # 训练集路径
    vocab_dir = "./THUCNews/data/vocab.pkl"               # 词表保存路径
    pretrain_dir = "./THUCNews/data/sgns.sogou.char"      # 预训练词向量文件路径
    emb_dim = 300                                # 词向量维度
    filename_trimmed_dir = "./THUCNews/data/embedding_SougouNews"  # 最终保存词向量的文件路径

    # 加载词表，如果不存在就重新构建并保存
    if os.path.exists(vocab_dir):
        word_to_id = pkl.load(open(vocab_dir, 'rb'))
    else:
        tokenizer = lambda x: [y for y in x]  # 按字符切分
        word_to_id = build_vocab(train_dir, tokenizer=tokenizer, max_size=MAX_VOCAB_SIZE, min_freq=1)
        pkl.dump(word_to_id, open(vocab_dir, 'wb'))

    # 随机初始化所有词的词向量
    embeddings = np.random.rand(len(word_to_id), emb_dim)

    # 打开预训练的词向量文件
    f = open(pretrain_dir, "r", encoding="utf-8")
    for i, line in enumerate(f.readlines()):
        line = line.strip().split(" ")
        if line[0] in word_to_id:  # 如果词表中有该词
            idx = word_to_id[line[0]]  # 找到词的编号
            emb = [float(x) for x in line[1:301]]  # 取出词向量（300维）
            embeddings[idx] = np.asarray(emb, dtype="float32")  # 替换为预训练的向量
    f.close()

    # 保存最终处理好的词向量（npz压缩格式）
    np.savez_compressed(filename_trimmed_dir, embeddings=embeddings)
