🇬🇧 [EN](./README.md) | 🇨🇳 [中文](README_zh.md)

# TextCNN Chinese Text Classification

A Chinese text classification project based on TextCNN, implemented with PyTorch.

> **Note**: This project is based on the excellent work from [Chinese-Text-Classification-Pytorch](https://github.com/649453932/Chinese-Text-Classification-Pytorch) by [649453932](https://github.com/649453932). The original repository provides implementations of multiple text classification models including TextCNN, TextRNN, FastText, TextRCNN, BiLSTM_Attention, DPCNN, and Transformer.

## Project Structure

```
.
├── models/                    # Model definitions
│   ├── TextCNN.py            # TextCNN model implementation
│   ├── TextRNN.py            # TextRNN model implementation
│   ├── FastText.py           # FastText model implementation
│   └── Transformer.py        # Transformer model implementation
├── utils.py                  # General utility functions
├── utils_fasttext.py         # FastText-style utility functions
├── train_eval.py             # Training and evaluation functions
├── main.py                   # Main program entry
├── requirements.txt          # Python dependencies
├── README.md                 # English documentation
├── README_zh.md              # Chinese documentation
└── THUCNews/                 # Dataset directory
    ├── data/
    │   ├── train.txt         # Training set (180K samples)
    │   ├── dev.txt           # Validation set (10K samples)
    │   ├── test.txt          # Test set (10K samples)
    │   ├── class.txt         # Class labels
    │   └── vocab.pkl         # Vocabulary file
    ├── saved_dict/           # Model checkpoints
    └── log/                  # Training logs
```

## Dataset Information

### THUCNews Dataset
This project uses the THUCNews dataset with the following data distribution:

- Training set: 180,000 samples
- Validation set: 10,000 samples
- Test set: 10,000 samples

### Pre-trained Word Vectors
This project supports using pre-trained Chinese word vectors. Recommended sources include:

1. Sogou News Word Vectors (default)
   - Source: Sogou Labs
   - Corpus size: 3.7G
   - Vocabulary size: 1.2M
   - Download: [Sogou News Word Vectors](http://www.sogou.com/labs/)

2. Other optional word vectors (from Chinese-Word-Vectors project):
   - Baidu Encyclopedia (4.1G, 5.4M vocabulary)
   - Chinese Wikipedia (1.3G, 2.1M vocabulary)
   - People's Daily News (3.9G, 1.6M vocabulary)
   - Financial News (6.2G, 2.7M vocabulary)
   - Zhihu Q&A (2.1G, 1.1M vocabulary)
   - Weibo (0.73G, 850K vocabulary)
   - Literature Works (0.93G, 702K vocabulary)

For more word vector resources, please refer to: [Chinese-Word-Vectors](https://github.com/Embedding/Chinese-Word-Vectors)

## Model Features

The TextCNN model has the following characteristics:

1. Uses convolutional neural networks for text classification
2. Employs n-gram feature extraction:
   - Uses bigram (2-gram) and trigram (3-gram) features
   - n-gram feature space size: 250499 (hash bucket size)
   - Maps consecutive word combinations to a fixed-size feature space through hash functions

## Configuration Parameters

Main configuration parameters include:

```python
self.num_epochs = 20            # Number of training epochs
self.batch_size = 128          # Batch size
self.pad_size = 32             # Length of each sentence (padding/truncating)
self.learning_rate = 1e-3      # Learning rate
self.embed = 300               # Character vector dimension
self.filter_sizes = (2, 3, 4)  # Convolutional kernel sizes
self.num_filters = 256         # Number of convolutional kernels
```

## Usage

```bash
# Use randomly initialized word vectors
python main.py --model TextCNN --embedding random

# Use pre-trained word vectors
python main.py --model TextCNN --embedding pre_trained
```

## Training Process

Data processing per epoch:
- Training set: 180,000 × 20 epochs = 3,600,000 samples
- Validation set: 10,000 × 20 epochs = 200,000 samples
- Test set: 10,000 samples (evaluated only after training completion)

## Requirements

- Python 3.x
- PyTorch
- NumPy
- tqdm

## Notes

1. Ensure the dataset is correctly placed in the THUCNews/data/ directory
2. Vocabulary will be automatically built on first run
3. The model will automatically use GPU (if available) or CPU for training
4. When using pre-trained word vectors, ensure the vector files are correctly placed in the THUCNews/data/ directory



